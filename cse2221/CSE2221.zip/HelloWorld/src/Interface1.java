
public interface Interface1 {

    public static void helper(int x) {

    }

}

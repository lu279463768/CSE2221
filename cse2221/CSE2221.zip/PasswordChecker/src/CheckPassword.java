import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * implement a program that checks whether a string entered by the user meets
 * several criteria to qualify as a valid password.
 *
 * @author Vivian Lu
 */
public final class CheckPassword {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private CheckPassword() {
    }

    /**
     * Checks whether the given String satisfies the OSU criteria for a valid
     * password. Prints an appropriate message to the given output stream.
     *
     * @param s
     *            the String to check
     * @param out
     *            the output stream
     */
    private static void checkPassword(String s, SimpleWriter out) {
        int flag = 0;
        boolean isValid = false;
        //first step, only check that the string satisfies the length requirement.
        if (s.length() >= 8) {
            if (containsUpperCaseLetter(s)) {
                flag++;
            } else if (!containsUpperCaseLetter(s) && flag >= 3) {
                isValid = true;
            } else if (containsLowerCaseLetter(s)) {
                flag++;
            } else if (!containsLowerCaseLetter(s) && flag >= 3) {
                isValid = true;
            } else if (containsDigit(s)) {
                flag++;
            } else if (!containsDigit(s) && flag >= 3) {
                isValid = true;
            } else if (containsSpecialCharacter(s)) {
                flag++;
            } else if (!containsSpecialCharacter(s) && flag >= 3) {
                isValid = true;
            }

            if (!containsDigit(s) && flag < 3) {
                out.println("Missing digit");
            }
            if (!containsSpecialCharacter(s) && flag < 3) {
                out.println("Missing special letter.");
            }
            if (!containsUpperCaseLetter(s) && flag < 3) {
                out.println("Missing upper case letter.");
            }
            if (!containsLowerCaseLetter(s) && flag < 3) {
                out.println("Missing lower case letter.");
            }

            if (!isValid) {
                out.println(s + " is an invalid password");
            } else if (isValid) {
                out.println(s + " is a valid password.");
            }

        } else {
            out.println("Invalid password,length is less than 8 characters.");
        }
    }

    /**
     * Checks if the given String contains an upper case letter.
     *
     * @param s
     *            the String to check
     * @return true if s contains an upper case letter, false otherwise
     */
    private static boolean containsUpperCaseLetter(String s) {
        boolean flag = false;
        for (int i = 0; i < s.length() && flag == false; i++) {
            if (Character.isUpperCase(s.charAt(i))) {
                flag = true;
            }
        }
        return flag;
    }

    /**
     * Checks if the given String contains an lower case letter.
     *
     * @param s
     *            the String to check
     * @return true if s contains an lower case letter, false otherwise
     */
    private static boolean containsLowerCaseLetter(String s) {
        boolean flag = false;
        for (int i = 0; i < s.length() && flag == false; i++) {
            if (Character.isLowerCase(s.charAt(i))) {
                flag = true;
            }
        }
        return flag;
    }

    /**
     * Checks if the given String contains a digit.
     *
     * @param s
     *            the String to check
     * @return true if s contains a digit, false otherwise
     */
    private static boolean containsDigit(String s) {
        boolean flag = false;
        for (int i = 0; i < s.length() && flag == false; i++) {
            if (Character.isDigit(s.charAt(i))) {
                flag = true;
            }
        }
        return flag;
    }

    /**
     * Checks if the given String contains a special character.
     *
     * @param s
     *            the String to check
     * @return true if s contains a special character, false otherwise
     */
    private static boolean containsSpecialCharacter(String s) {
        boolean flag = false;
        String specialCharacters = "!@#$%^&*()_-+={}[]:;,.?";
        for (int i = 0; i < specialCharacters.length() && flag == false; i++) {
            char c = specialCharacters.charAt(i);
            if (s.indexOf(c) >= 0 && s.indexOf(c) < s.length()) {
                flag = true;
            }
        }
        return flag;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Please give a string as a password candidate: ");
        String input = in.nextLine();
        checkPassword(input, out);

        out.print("Please give a new password: ");
        input = in.nextLine();
        while (!input.isEmpty()) {
            checkPassword(input, out);
            out.print("Please give a new password: ");
            input = in.nextLine();
        }
        out.println("Program ended.");

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
